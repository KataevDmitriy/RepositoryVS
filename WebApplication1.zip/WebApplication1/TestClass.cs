﻿namespace WebApplication1
{
    public class TestClass
    {
        public string? stroka 
        {
            get; 
            set; 
        }
    }
}
