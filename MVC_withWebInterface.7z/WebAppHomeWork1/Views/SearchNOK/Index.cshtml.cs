using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebAppHomeWork1.Views.SearchNOK
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
